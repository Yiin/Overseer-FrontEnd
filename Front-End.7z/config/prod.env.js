module.exports = {
  NODE_ENV: '"production"',
  WS_SERVER: '"overseer.io:6001"'
}
